# Chart to run scheduler plugin as a second scheduler in cluster.
