package topologyapi

// GroupName is the group name used in this package
const (
	GroupName = "topology.node.k8s.io"
)
