// +k8s:deepcopy-gen=package
// +k8s:defaulter-gen=TypeMeta
// +groupName=topology.node.k8s.io

// Package v1alpha1 is the v1alpha1 version of the API.
package v1alpha1 // import "github.com/k8stopologyawareschedwg/noderesourcetopology-api/pkg/apis/topology/v1alpha1"
